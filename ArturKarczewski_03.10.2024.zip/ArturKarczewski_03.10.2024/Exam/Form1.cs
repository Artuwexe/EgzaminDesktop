using Exam.Properties;

namespace Exam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Eyekolor;
            if (radioButton1.Checked)
                Eyekolor = "niebieskie";
            else if (radioButton2.Checked)
                Eyekolor = "zielone";
            else
            {
                Eyekolor = "piwne";
            }
            if (textBox2.Text != "" && textBox3.Text != "")
            {
                if (textBox1.Text != "")
                    MessageBox.Show(textBox2.Text + " " + textBox3.Text + ", Kolor oczu: " + Eyekolor);
                else
                {
                    MessageBox.Show("Wprowad� dane");
                }
            }
        }

        private void opusc(object sender, EventArgs e)
        {
            string Numer = textBox1.Text;
            if(Numer != "111" && Numer != "000" && Numer != "333")
            {
                pictureBox1.Image = null;
                pictureBox2.Image = null;
            }
            else
            {
                switch (Numer)
                {
                    case "000":
                        pictureBox1.Image = Resources._000_zdjecie;
                        pictureBox2.Image = Resources._000_odcisk;
                        break;
                    case "111":
                        pictureBox1.Image = Resources._111_zdjecie;
                        pictureBox2.Image = Resources._111_odcisk;
                        break;
                    case "333":
                        pictureBox1.Image = Resources._333_zdjecie;
                        pictureBox2.Image = Resources._333_odcisk;
                        break;
                    default:
                        pictureBox1.Image = null;
                        pictureBox2.Image = null;
                        break;
                }
            }
        }
    }
}
